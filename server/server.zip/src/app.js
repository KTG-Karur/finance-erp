import dotenv from 'dotenv';
dotenv.config();

import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import sensible from '@fastify/sensible';

import fastifyStatic from '@fastify/static';
import fastifyMultipart from '@fastify/multipart';
import path from 'path';
import fs from 'fs';

import masterDbPlugin from './plugins/masterDb.js';
import tenantDbPlugin from './plugins/tenantDb.js';
import dbPlugin from './plugins/db.js';
import authPlugin from './plugins/auth.js';
import tenantGuardPlugin from './plugins/tenantGuard.js';
import moduleGuardPlugin from './plugins/moduleGuard.js';

import authRoutes from './modules/auth/auth.routes.js';
import uploadRoutes from './modules/upload/upload.routes.js';
import financeRoutes from './finance/finance.routes.js';
import orgRoutes from './modules/org/org.routes.js';
import employeeRoutes from './modules/employee/employee.routes.js';
import roleRoutes from './modules/roles/roles.routes.js';
import trashRoutes from './modules/trash/trash.routes.js';
import { ensureCompanyUploadDirectories } from './shared/utils/fileStorage.js';

// Fastify's default bodyLimit is 1MB — too small for real uploads: a single
// 5MB photo becomes ~6.7MB once base64-encoded in the JSON body, and the
// borrower KYC form can submit up to 6 documents (10MB each) in one request —
// worst case ~87MB of base64. Actual per-file ceilings are still enforced
// individually server-side (see shared/validators/fileSize.js); this is just
// the outer transport limit, set with headroom above that worst case.
const fastify = Fastify({
  logger: false,
  bodyLimit: 100 * 1024 * 1024,
  ajv: {
    customOptions: {
      allowUnionTypes: true
    }
  }
});

// Origin allowlist instead of `origin: true` (which reflects any caller's Origin
// header back — with credentials:true that's effectively "trust every website").
// Comma-separated via CORS_ORIGINS in .env; defaults cover the Vite dev server.
const allowedOrigins = (process.env.CORS_ORIGINS || 'http://localhost:3000,http://127.0.0.1:3000')
  .split(',')
  .map(o => o.trim())
  .filter(Boolean);

// Register Core Plugins
await fastify.register(cors, {
  origin(origin, cb) {
    // Same-origin/non-browser requests (curl, server-to-server, mobile) send no
    // Origin header at all — those aren't a CSRF/XSS vector this check guards
    // against, so let them through; only browser cross-origin calls get checked.
    // Passing `false` (rather than an Error) just omits the CORS headers — the
    // browser itself blocks the response from being read; the server still
    // replies normally instead of surfacing a raw 500.
    cb(null, !origin || allowedOrigins.includes(origin));
  },
  credentials: true
});

await fastify.register(helmet, {
  // This is a JSON API consumed by a separately-hosted SPA (different origin/port
  // in dev, likely a different origin in prod too) — helmet's default
  // Cross-Origin-Resource-Policy: 'same-origin' would make the browser block the
  // client from reading every response. CSP is likewise an HTML-page concern and
  // has nothing to protect here since this server never renders HTML.
  contentSecurityPolicy: false,
  crossOriginResourcePolicy: { policy: 'cross-origin' }
});

// global: false — rate limiting is opt-in per route now, not applied to every
// endpoint by default. Only the login/credential-guessing routes in
// auth.routes.js (bruteForceGuard) opt in via their own `config.rateLimit`.
await fastify.register(rateLimit, {
  global: false,
  // @fastify/rate-limit throws whatever this returns and relies on `.statusCode`
  // to set the reply status — omitting it silently produces a 500 instead of 429.
  errorResponseBuilder: (request, context) => ({
    statusCode: context.statusCode,
    success: false,
    error: 'Too Many Requests',
    message: `Rate limit exceeded. Try again in ${Math.ceil(context.ttl / 1000)}s.`
  })
});

const uploadsDir = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

await fastify.register(fastifyStatic, {
  root: uploadsDir,
  prefix: '/uploads/',
  decorateReply: false
});

await fastify.register(fastifyMultipart, {
  limits: {
    fileSize: 25 * 1024 * 1024, // 25MB max file size
    files: 10
  }
});

await fastify.register(sensible);
await fastify.register(masterDbPlugin);
await fastify.register(tenantDbPlugin);
await fastify.register(dbPlugin);
await fastify.register(authPlugin);
await fastify.register(tenantGuardPlugin);
await fastify.register(moduleGuardPlugin);

// Pre-create upload directories for all active tenant companies on boot
try {
  const [activeCompanies] = await fastify.masterDb.query('SELECT company_code FROM companies WHERE is_active = 1');
  for (const c of activeCompanies) {
    if (c.company_code) await ensureCompanyUploadDirectories(c.company_code);
  }
} catch (e) {
  // Ignored if masterDb not yet migrated
}

// Health Check
fastify.get('/health', async (request, reply) => {
  return { status: 'OK', system: 'Database-per-Tenant Financial ERP API', timestamp: new Date() };
});

// Register Auth & Multipart Direct Disk Upload Routes
fastify.register(authRoutes, { prefix: '/api/auth' });
fastify.register(uploadRoutes, { prefix: '/api' });
fastify.register(uploadRoutes, { prefix: '/api/v1' });

// Register General Finance Domain Engine
fastify.register(financeRoutes, { prefix: '/api/finance' });
fastify.register(financeRoutes, { prefix: '/api' });

// Org (branches/sub-companies), Employees and Roles
fastify.register(orgRoutes, { prefix: '/api' });
fastify.register(employeeRoutes, { prefix: '/api/employees' });
fastify.register(roleRoutes, { prefix: '/api/roles' });
fastify.register(trashRoutes, { prefix: '/api' });

// Global Error Handler
fastify.setErrorHandler((error, request, reply) => {
  const statusCode = error.statusCode || (reply.statusCode >= 400 ? reply.statusCode : 500);
  if (statusCode >= 500) {
    console.error(`\x1b[31m[ERROR 500] ${request.method} ${request.url}\x1b[0m:`, error);
  }
  return reply.code(statusCode).send({
    success: false,
    message: error.message || 'Internal Server Error'
  });
});

const PORT = Number(process.env.PORT) || 5000;
const HOST = process.env.HOST || '0.0.0.0';

async function start() {
  try {
    await fastify.listen({ port: PORT, host: HOST });
    const displayHost = HOST === '0.0.0.0' ? 'localhost' : HOST;
    console.log(`API server listening on port ${PORT} (http://${displayHost}:${PORT})`);
  } catch (err) {
    console.error('[ERROR] Server failed to start:', err.message);
    process.exit(1);
  }
}

start();
